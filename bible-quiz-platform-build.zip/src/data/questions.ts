import { Question, Book } from '../types';

export const sampleQuestions: Question[] = [
  // Joshua questions
  {
    id: 'joshua-1',
    book: 'Joshua',
    text: 'Who was Joshua\'s father?',
    options: ['Nun', 'Caleb', 'Moses', 'Aaron'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'joshua-2',
    book: 'Joshua',
    text: 'How many days did the Israelites march around Jericho?',
    options: ['7', '6', '40', '12'],
    correctAnswer: 1,
    points: 10,
  },
  {
    id: 'joshua-3',
    book: 'Joshua',
    text: 'What did Rahab use to help the spies escape?',
    options: ['A rope', 'A secret tunnel', 'A red cord', 'A disguise'],
    correctAnswer: 2,
    points: 15,
  },
  // 1 Kings questions
  {
    id: '1kings-1',
    book: '1 Kings',
    text: 'Who was Solomon\'s mother?',
    options: ['Bathsheba', 'Abishag', 'Jezebel', 'Hannah'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: '1kings-2',
    book: '1 Kings',
    text: 'How many years did it take to build the temple?',
    options: ['7', '40', '12', '20'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: '1kings-3',
    book: '1 Kings',
    text: 'What was the first miracle Elijah performed?',
    options: ['Raising the widow\'s son', 'Calling fire from heaven', 'Drought for 3 years', 'Parting the Jordan'],
    correctAnswer: 2,
    points: 15,
  },
  // Proverbs questions
  {
    id: 'proverbs-1',
    book: 'Proverbs',
    text: 'What is the beginning of wisdom?',
    options: ['The fear of the Lord', 'Understanding', 'Knowledge', 'Discipline'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'proverbs-2',
    book: 'Proverbs',
    text: 'Who wrote most of the Proverbs?',
    options: ['Solomon', 'David', 'Hezekiah', 'Agur'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'proverbs-3',
    book: 'Proverbs',
    text: 'What is better than gold?',
    options: ['Wisdom', 'Silver', 'Rubies', 'Understanding'],
    correctAnswer: 0,
    points: 15,
  },
  // Romans questions
  {
    id: 'romans-1',
    book: 'Romans',
    text: 'Who wrote the book of Romans?',
    options: ['Paul', 'Peter', 'John', 'Luke'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'romans-2',
    book: 'Romans',
    text: 'What is the wages of sin?',
    options: ['Death', 'Suffering', 'Separation from God', 'Eternal punishment'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'romans-3',
    book: 'Romans',
    text: 'What are we justified by?',
    options: ['Faith', 'Works', 'Grace', 'The Law'],
    correctAnswer: 0,
    points: 15,
  },
  // James questions
  {
    id: 'james-1',
    book: 'James',
    text: 'Who wrote the book of James?',
    options: ['James, brother of Jesus', 'James, son of Zebedee', 'James, son of Alphaeus', 'James the Less'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'james-2',
    book: 'James',
    text: 'What is faith without works?',
    options: ['Dead', 'Useless', 'Incomplete', 'Hypocrisy'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'james-3',
    book: 'James',
    text: 'What can no man tame?',
    options: ['The tongue', 'The heart', 'The flesh', 'The mind'],
    correctAnswer: 0,
    points: 15,
  },
  // General Bible Knowledge questions
  {
    id: 'general-1',
    book: 'General Bible Knowledge',
    text: 'How many books are in the Bible?',
    options: ['66', '73', '39', '27'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'general-2',
    book: 'General Bible Knowledge',
    text: 'What is the first book of the Bible?',
    options: ['Genesis', 'Exodus', 'Matthew', 'John'],
    correctAnswer: 0,
    points: 10,
  },
  {
    id: 'general-3',
    book: 'General Bible Knowledge',
    text: 'Who was thrown into a lion\'s den?',
    options: ['Daniel', 'David', 'Samson', 'Jonah'],
    correctAnswer: 0,
    points: 15,
  },
];

export function getQuestionsByBook(book: Book): Question[] {
  return sampleQuestions.filter(q => q.book === book);
}